package doore.dao;


public interface CustomerDAO {
	
}
