package doore.control;

public class CommandFactory {
	public static Command createCommand(String pathName) {
		Command target = null;

		switch (pathName) {
		case "/":
			target = new TestCommand();
			break;
		case "/test":
			target = new TestCommand();
			break;
		case "/customer":
			target = new CustomerCommand();
			break;
		case "/village":
			target = new VillageCommand();
			break;
		case "/product":
			target = new ProductCommand();
			break;
		case "/sharing":
			target = new SharingCommand();
			break;		
		}

		return target;
	}

}
