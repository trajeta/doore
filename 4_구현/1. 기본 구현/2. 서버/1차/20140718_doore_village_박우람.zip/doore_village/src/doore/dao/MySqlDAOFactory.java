package doore.dao;

public class MySqlDAOFactory extends DAOFactory {
	public CustomerDAO getCustomerDAO() {
		return new MySqlCustomerDAO();
	}
	
	public VillageDAO getVillageDAO() {
		return new MySqlVillageDAO();
	}
}