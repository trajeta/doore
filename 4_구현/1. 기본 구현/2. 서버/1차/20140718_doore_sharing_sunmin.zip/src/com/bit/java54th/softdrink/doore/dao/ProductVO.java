package com.bit.java54th.softdrink.doore.dao;

public class ProductVO {
	private int id;
	private String title;
	private String author;
	private double price;
	private int qty;
	
	public ProductVO(int id, String title, String author, double price, int qty) {
		this.id = id;
		this.title = title;
		this.author = author;
		this.price = price;
		this.qty = qty;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	public int getId() {
		return id;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public double getPrice() {
		return price;
	}
	
	public int getQty() {
		return qty;
	}
	
	

}
