package com.bit.java54th.softdrink.doore.dao;

import java.util.List;

public interface CustomerDAO {
	public List<ProductVO> findAllBooks();
	public ProductVO findBookByID(int id);
}
