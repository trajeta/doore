package com.bit.java54th.softdrink.doore.dao;

import java.util.List;

public class MySqlProductDAO implements ProductDAO {

	@Override
	public List<ProductVO> findAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductVO findBookByID(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
