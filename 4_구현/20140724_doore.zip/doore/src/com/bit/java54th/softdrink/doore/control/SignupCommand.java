package com.bit.java54th.softdrink.doore.control;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bit.java54th.softdrink.doore.dao.CustomerDAO;
import com.bit.java54th.softdrink.doore.dao.CustomerVO;
import com.bit.java54th.softdrink.doore.dao.DAOFactory;

public class SignupCommand implements Command {
	public CommandResult execute(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
		CommandResult commandResult = new CommandResult("/WEB-INF/view/signup.jsp");

		return commandResult;
	}
}