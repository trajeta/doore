package com.bit.java54th.softdrink.doore.control;

public class CommandFactory {
	public static Command createCommand(String pathName) {
		Command target = null;
		
		switch (pathName) {
// 		    case "/product":
//				target = new ProductCommand();  
//				break;
			case "/customer":
				target = new CustomerCommand();  
				break;
//			case "/village":
//				target = new VillageCommand();
//				break;
//			case "/sharing":
//				target =  new SharingCommand();
//				break;
				
			case "/login":
				target = new LoginCommand();
				break;
				
			case "/findPassword":
				target = new FindPasswordCommand();
				break;
				
			default :
				target = new CustomerCommand();
				break;
		}
		
		return target;
	}

}
