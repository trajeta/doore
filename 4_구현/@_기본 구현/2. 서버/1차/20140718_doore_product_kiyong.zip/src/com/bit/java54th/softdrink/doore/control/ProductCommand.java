package com.bit.java54th.softdrink.doore.control;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sun.font.CreatedFontTracker;

import com.bit.java54th.softdrink.doore.dao.CategoryVO;
import com.bit.java54th.softdrink.doore.dao.DAOFactory;
import com.bit.java54th.softdrink.doore.dao.ProductDAO;
import com.bit.java54th.softdrink.doore.dao.ProductVO;


public class ProductCommand implements Command {
	public CommandResult execute(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
		response.setContentType("text/html;charset=UTF-8");
		CommandResult commandResult = null;
		
		String todo = request.getParameter("todo");
		
		if (todo.equals("add")) 
			commandResult = doAdd(request, response);
		else if (todo.equals("remove"))
			commandResult = doRemove(request, response);

		else if (todo.equals("update"))
			commandResult = doUpdate(request,response);
		return commandResult;
	}

	public com.bit.java54th.softdrink.doore.control.CommandResult 
		doUpdate(HttpServletRequest request, HttpServletResponse response) {
		CommandResult commandResult;
		response.setContentType("text/html;charset=UTF-8");
		byte[] img=null;
		int successnumber = getupdateProduct(4, "업데이트빵", img,"텍스트1","텍스트2","텍스트3","긴텍스트",1);
		
		request.setAttribute("updateproduct", successnumber);
		
		commandResult = new CommandResult("/WEB-INF/view/productupdate.jsp");
		
		return commandResult;
	}

	

	public com.bit.java54th.softdrink.doore.control.CommandResult 
		doRemove(HttpServletRequest request, HttpServletResponse response) {
		CommandResult commandResult;
		response.setContentType("text/html;charset=UTF-8");

		int successnumber = getdeleteProduct(8);
		
		request.setAttribute("deleteproduct", successnumber);
		
		commandResult = new CommandResult("/WEB-INF/view/productremove.jsp");
		
		return commandResult;
	}

	public com.bit.java54th.softdrink.doore.control.CommandResult
		doAdd(HttpServletRequest request, HttpServletResponse response) {
		CommandResult commandResult;
		
		
		byte[] img =null;
		int successnumber = getcreateProduct("테스트",img,3,3,"상세1","상세2","상세3","큰거",3);
		
		request.setAttribute("createproduct", successnumber);
		
		
		
		commandResult = new CommandResult("/WEB-INF/view/productadd.jsp");
		
		return commandResult;
	}
	public List<ProductVO> getfindAllProducts(){
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.findAllProducts();
	}
	public ProductVO getfindProductByID(int productid) {
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.findProductByID(productid);
	}
	public List<ProductVO> getfindIDProdcuts(int customer_id){
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.findIDProdcuts(customer_id);
	}
	public int getcreateProduct(String product_name, byte[] product_picture,int customer_id,int category_id,
			String detail_text_1,String detail_text_2, String detail_text_3, String detail_decription,
			int village_id) {
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.createProduct(product_name,product_picture,customer_id,category_id,detail_text_1,detail_text_2,detail_text_3,
				detail_decription,village_id);
	}
	public List<ProductVO> getfindProductByVillageID(int village_id){
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.findProductByVillageID(village_id);
	}
	public int getupdateProduct(int product_id, String product_name, byte[] product_picture,String detail_field1,
							String detail_field2,String detail_field3,String detail_decription,int village_id){
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.updateProduct(product_id, product_name, product_picture,detail_field1,detail_field2,detail_field3,detail_decription, village_id);
	}
	
	public int getdeleteProduct(int id){
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.deleteProduct(id);
	}
	public CategoryVO getfindCategoryID(int category_id){
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.findCategoryID(category_id);
	}
	public int getcreateProduct(String product_name, byte[] product_picture,int customer_id,int category_id,
			String detail_text_1,String detail_text_2, String detail_text_3, String detail_decription){
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.createProduct(product_name,product_picture,customer_id,category_id ,detail_text_1,detail_text_2,
				detail_text_3,detail_decription);
	}
}
