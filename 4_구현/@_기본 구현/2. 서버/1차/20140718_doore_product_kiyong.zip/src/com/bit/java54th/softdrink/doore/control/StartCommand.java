package com.bit.java54th.softdrink.doore.control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bit.java54th.softdrink.doore.dao.DAOFactory;
import com.bit.java54th.softdrink.doore.dao.ProductDAO;
import com.bit.java54th.softdrink.doore.dao.ProductVO;

public class StartCommand implements Command {

	@Override
	public CommandResult execute(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		CommandResult commandResult = null;
		request.setAttribute("products", getAllProducts());
		request.setAttribute("findproductid", findProductByID(6));
	commandResult = new CommandResult("/WEB-INF/view/start.jsp");
	return commandResult;
	}
	List<ProductVO> getAllProducts() {
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.findAllProducts();	
	}
	ProductVO findProductByID(int productid) {
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		ProductDAO productDAO = mysqlFactory.getProductDAO();
		
		return productDAO.findProductByID(productid);
	}
}
