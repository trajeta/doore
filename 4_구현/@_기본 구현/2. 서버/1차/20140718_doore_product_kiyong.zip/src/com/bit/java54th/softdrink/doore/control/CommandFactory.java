package com.bit.java54th.softdrink.doore.control;

public class CommandFactory {
	public static Command createCommand(String pathName) {
		Command target = null;
		
		switch (pathName) {
 		    case "/product":
				target = new ProductCommand();  
				break;
 		    case "/*":
 		    	target = new StartCommand();
 		   default:
 			   target = new StartCommand();
//			case "/customer":
//				target = new CustomerCommand();  
//				break;
//			case "/village":
//				target = new VillageCommand();
//				break;
//			case "/sharing":
//				target =  new SharingCommand();
//				break;
		}
		
		return target;
	}

}
